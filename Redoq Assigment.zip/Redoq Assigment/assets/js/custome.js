
// active class add navlink
var selector = '.navbar-nav li a';

$(selector).on('click', function(){
    $(selector).removeClass('active');
    $(this).addClass('active');
});


// banner slider
const swiper = new Swiper(".mySwiper", {
  loop: true,
  spaceBetween: 30,
  slidesPerView: 1,
  pagination: {
    el: ".swiper-pagination",
    type: "progressbar",
  },
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
  on: {
    init: function () {
      updateSlideNumber(this);
    },
    slideChange: function () {
      updateSlideNumber(this);
    },
  },
});

function updateSlideNumber(swiperInstance) {
  const total = 6;
  const current = swiperInstance.realIndex + 1;
  document.getElementById("current").textContent = String(current).padStart(2, '0');
  document.getElementById("total").textContent = String(total).padStart(2, '0');
}

// brand slider
$(document).ready(function() {
  $('.brandslider').owlCarousel({
    loop: true,
    margin: 10,
    nav: false,
    dots:false,
    autoplay: true,
    slideTransition: 'linear',
    autoplaySpeed: 6000,
    smartSpeed: 6000,
    responsive: {
      0: {
        items: 2
      },
      575: {
        items: 3
      },
      1000: {
        items: 5
      }
    }
  });

  $('.brandslider').trigger('play.owl.autoplay', [2000]);

  function setSpeed() {
    $('.brandslider').trigger('play.owl.autoplay', [6000]);
  }

  setTimeout(setSpeed, 1000);
});

// component slider 
$('.componentsslider').owlCarousel({
    loop:true,
    margin:27,
    nav:true,
     navText: [
      "<span class='custom-nav'><img src='assets/images/arrowleft.png'><span class='nav-label'>Prev</span></span>",
        "<span class='custom-nav'><span class='nav-label'>Next</span><img src='assets/images/arrowright.png'></span>"
    ],
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        700:{
          items:2
        },
        1000:{
            items:2
        }
    }
})

// =====video modal===================
$('.pulsebtn').click(function(){
  var buttonId = $(this).attr('id');
  $('#modal-container').removeAttr('class').addClass(buttonId);
  $('body').addClass('modal-active');
})

$('#modal-container').click(function(){
  $(this).addClass('out');
  $('body').removeClass('modal-active');
});


// project slider
$('.projectslider').owlCarousel({
    loop:true,
    margin:42,
    nav:true,
     navText: [
      "<span class='custom-nav'><img src='assets/images/arrowleft.png'></span>",
        "<span class='custom-nav'><img src='assets/images/arrowright.png'></span>"
    ],
     dots: true, 
      dotsEach: 1 ,
    responsive:{
        0:{
            items:1
        },
        700:{
            items:2
        },
        1000:{
            items:3
        }
    }
})
// tab section
  function showTab(index) {
      const tabs = document.querySelectorAll('.tab');
      const contents = document.querySelectorAll('.tab-content');

      tabs.forEach((tab, i) => {
        tab.classList.toggle('active', i === index);
        contents[i].classList.toggle('active', i === index);
      });
    }

  // testimonial slider

  $('.testimonial_slider').owlCarousel({
    loop:true,
    margin:15,
    nav:false,
    dots:false,
       autoplay:true,
    autoplayTimeout:2000,
    responsive:{
        0:{
            items:1
        },
        575:{
           items:1.5
        },
        767:{
            items:2.5
        },
        900:{
          items:3.5
        },
        1300:{
            items:4.5
        }
    }
})